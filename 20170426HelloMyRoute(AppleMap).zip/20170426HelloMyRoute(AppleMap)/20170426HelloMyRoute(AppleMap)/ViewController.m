//
//  ViewController.m
//  20170426HelloMyRoute(AppleMap)
//
//  Created by user35 on 2017/4/26.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *labelTest;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)goBtnPressed:(id)sender {
    
//    NSString *targetAddress = @"新北市三重區中正北路100號";
    NSString *targetAddress = @"台北市館前路45號";
    CLGeocoder *geocoder1 = [CLGeocoder new];  //CLGeocoder是住址轉換或經緯度轉換
    [geocoder1 geocodeAddressString:targetAddress completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {//placemarks別的國家可能一個住址有不同資料
        
        if (error) { //異常檢查
            NSLog(@"Geocoder fail:%@",error);
            return ;
        }
        if (placemarks.count == 0) { //異常檢查
            NSLog(@"Can't find any result");
            return;
        }
        CLPlacemark *placemark = placemarks.firstObject;
        CLLocationCoordinate2D coordinate = placemark.location.coordinate;
        NSLog(@"%@ ==> %f,%f",targetAddress,coordinate.latitude,coordinate.longitude);
        
        //Decide Source MapItem
        CLLocationCoordinate2D sourceCoordinate = CLLocationCoordinate2DMake(24.686525, 121.815312);
        MKPlacemark *sourcePlace = [[MKPlacemark alloc]initWithCoordinate:sourceCoordinate];
        MKMapItem *sourceMapItem = [[MKMapItem alloc]initWithPlacemark:sourcePlace];
        
        
        //Decide Target MapItem
        MKPlacemark *targetPlace = [[MKPlacemark alloc]initWithPlacemark:placemark];
        MKMapItem *targetMapItem = [[MKMapItem alloc]initWithPlacemark:targetPlace];
        //Options
        NSDictionary *options = @{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving};
        
//        [targetMapItem openInMapsWithLaunchOptions:options];        
        [MKMapItem openMapsWithItems:@[sourceMapItem,targetMapItem] launchOptions:options];
        
    }];

//    [geocoder1 geocodeAddressString:targetAddress completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
//        
//    }];//不能同個物件同時多次查詢，但可宣告多個CLGeocoder，
    
    //Reverse Geocoder
    CLGeocoder *geocoder2 = [CLGeocoder new];
    CLLocation *location = [[CLLocation alloc]initWithLatitude:25.045164 longitude:121.515154];
    [geocoder2 reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
    
        CLPlacemark *placemark = placemarks.firstObject;
        NSLog(@"Address: %@",placemark.addressDictionary);
        NSLog(@"PostCode: %@",placemark.postalCode);
//        self.labelTest.text = placemark.locality;

        
    }];
    
}




@end




